
function calculate() {
    const length = parseFloat(document.getElementById('length').value);
    const load = parseFloat(document.getElementById('load').value);
    if (!length || !load) {
        alert('Please enter both length and load');
        return;
    }
    const maxMoment = (load * Math.pow(length, 2)) / 8;
    const resultText = `Max Bending Moment = ${maxMoment.toFixed(2)} kNm`;
    document.getElementById('result').innerText = resultText;
    window.lastResult = { length, load, maxMoment };
}

function exportToExcel() {
    if (!window.lastResult) {
        alert('Please perform a calculation first.');
        return;
    }
    const wb = XLSX.utils.book_new();
    const ws_data = [["Beam Length (m)", "Uniform Load (kN/m)", "Max Moment (kNm)"],
                     [window.lastResult.length, window.lastResult.load, window.lastResult.maxMoment]];
    const ws = XLSX.utils.aoa_to_sheet(ws_data);
    XLSX.utils.book_append_sheet(wb, ws, "Beam Analysis");
    XLSX.writeFile(wb, "beam_analysis_result.xlsx");
}
